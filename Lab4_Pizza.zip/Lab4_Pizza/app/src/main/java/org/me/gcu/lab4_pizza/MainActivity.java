package org.me.gcu.lab4_pizza;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button submit;
    EditText email;
    CheckBox t1,t2,t3,t4;
    RadioButton c1,c2, yes,no;
    TextView textView2,textView3,textView4,textView5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        submit = (Button)findViewById(R.id.submit);
        submit.setOnClickListener(this);
        email = (EditText) findViewById(R.id.email1);
        t1 = (CheckBox) findViewById(R.id.t1);
        t2 = (CheckBox) findViewById(R.id.t2);
        t3 = (CheckBox) findViewById(R.id.t3);
        t4 = (CheckBox) findViewById(R.id.t4);
        c1 = (RadioButton) findViewById(R.id.c1);
        c2 = (RadioButton) findViewById(R.id.c2);
        yes = (RadioButton) findViewById(R.id.yes);
        no = (RadioButton) findViewById(R.id.no);
        textView2= (TextView) findViewById(R.id.textView2);
        textView3= (TextView) findViewById(R.id.textView3);
        textView4= (TextView) findViewById(R.id.textView4);
        textView5= (TextView) findViewById(R.id.textView5);
        no.setChecked(true);
    }


    @Override
    public void onClick(View v){

        String emailValue = String.valueOf(email.getText());
        Log.i("Email ", emailValue);
        String crustChoice="";
        //String[] toppings = {String.valueOf(t1), String.valueOf(t2), String.valueOf(t3), String.valueOf(t4)};
        CheckBox[] toppings = {t1,t2,t3,t4};
        String toppingChoice="";
        RadioButton[] cheese = {yes,no};
        RadioButton[] crust = {c1,c2};
        String extraCheese="";
        for (RadioButton r : cheese){
            if (r.isChecked()){
                extraCheese = String.valueOf(r.getText());
                //System.out.println("Extra cheese"+ extraCheese);
                Log.i("Extra Cheese",extraCheese);
            }
        }
        for (RadioButton c : crust){
            if (c.isChecked()){
                crustChoice = String.valueOf(c.getText());
                //System.out.println("Choice of crust"+ crustChoice);
                Log.i("Choice of crust",crustChoice);
            }
        }
        for(CheckBox t : toppings) {
            if (t.isChecked()) {
                toppingChoice += String.valueOf(t.getText());
                toppingChoice += " ";
                // System.out.println("Choice of topping "+toppingChoice)
            }
            else{
                    int x =1;
                    x++;
                    if (x == toppings.length){
                        toppingChoice += " No toppings have been selected.\n Therefore the pizza will be mozzarella. ";
                    }
            }
        }
        Log.i("Choice of topping",toppingChoice);



        //Alert Box with order Info
        // Create the object of AlertDialog Builder class
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

        // Set the message show for the Alert time
        builder.setMessage("Are the order details correct?\n\n Email: "+emailValue+"\n Crust: "+crustChoice+"\n Toppings: "+toppingChoice+"\n Extra Cheese: "+extraCheese);

        // Set Alert Title
        builder.setTitle("Order Summary");

        // Set Cancelable false for when the user clicks on the outside the Dialog Box then it will remain show
        builder.setCancelable(true);

        // Set the positive button with yes name Lambda OnClickListener method is use of DialogInterface interface.
        builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {
            // When the user click yes button then app will close
            finish();
        });

        // Set the Negative button with No name Lambda OnClickListener method is use of DialogInterface interface.
        builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
            // If user click no then dialog box is canceled.
            dialog.cancel();
        });

        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();
        // Show the Alert Dialog box
        alertDialog.show();

    }


}