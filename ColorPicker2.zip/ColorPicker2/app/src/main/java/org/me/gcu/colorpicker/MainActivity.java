package org.me.gcu.colorpicker;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView s1,s2,s3,s4,s5,s6;
    Button b1,b2,b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s1 = findViewById(R.id.s1);
        s2 = findViewById(R.id.s2);
        s2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s5.setBackgroundColor(Color.RED);
            }
        });
        s3 = findViewById(R.id.s3);
        s3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s5.setBackgroundColor(Color.GREEN);
            }
        });
        s4 = findViewById(R.id.s4);
        s4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s5.setBackgroundColor(Color.BLUE);
            }
        });
        s5 = findViewById(R.id.s5);
        s6 = findViewById(R.id.s6);

        s6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s5.setBackgroundColor(0xFFBB86FC);
            }
        });

        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("Button 1", "Clicked");
                s5.setBackgroundColor(Color.RED);
            }
        });
        b2 = findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("Button 2", "Clicked");
                s5.setBackgroundColor(Color.GREEN);
            }
        });
        b3 = findViewById(R.id.b3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("Button 3", "Clicked");
                s5.setBackgroundColor(Color.BLUE);
            }
        });
    }

    @Override
    public void onClick(View v){

    }
}